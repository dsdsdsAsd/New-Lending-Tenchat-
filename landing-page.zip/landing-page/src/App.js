import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      {/* Background Aurora Effect */}
      <div className="aurora-background"></div>

      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark fixed-top">
        <div className="container">
          <a className="navbar-brand fs-4 fw-bold" href="#home">TenSender</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item"><a className="nav-link" href="#features">Возможности</a></li>
              <li className="nav-item"><a className="nav-link" href="#how-it-works">Процесс</a></li>
              <li className="nav-item"><a className="nav-link" href="#pricing">Тарифы</a></li>
              <li className="nav-item"><a className="nav-link" href="#faq">FAQ</a></li>
            </ul>
            <a href="#pricing" className="btn btn-outline-light rounded-pill">Начать работу</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <header id="home" className="hero-section text-white text-center">
        <div className="container">
          <h1 className="display-2 fw-bolder">Новый уровень лидогенерации в TenChat</h1>
          <p className="lead my-4 mx-auto" style={{ maxWidth: '700px' }}>Автоматизированный поиск и отправка персонализированных сообщений для B2B-продаж.</p>
          <a href="#pricing" className="btn btn-light btn-lg rounded-pill px-5 py-3 fw-bold">Запустить на 7 дней бесплатно</a>
          <div className="hero-product-shot">
            <div className="product-ui-header"></div>
            <div className="product-ui-sidebar"></div>
            <div className="product-ui-content"></div>
          </div>
        </div>
      </header>

      {/* Features Section (Bento Grid) */}
      <section id="features" className="py-5">
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="fw-bold text-white">Инструменты для доминирования</h2>
            <p className="text-white-50">Все, что нужно для построения потока клиентов.</p>
          </div>
          <div className="bento-grid">
            <div className="bento-item bento-item-large glass-card">
              <i className="bi bi-robot fs-1 mb-3"></i>
              <h5 className="fw-bold">AI-Персонализация</h5>
              <p>Нейросеть анализирует профиль и пишет уникальное сообщение, которое не отличить от написанного вручную.</p>
            </div>
            <div className="bento-item glass-card">
              <i className="bi bi-graph-up-arrow fs-1 mb-3"></i>
              <h5 className="fw-bold">Live-Аналитика</h5>
              <p>Отслеживайте воронку в реальном времени.</p>
            </div>
            <div className="bento-item glass-card">
              <i className="bi bi-shield-shaded fs-1 mb-3"></i>
              <h5 className="fw-bold">Макс. безопасность</h5>
              <p>Эмуляция человеческих действий и поведенческих факторов.</p>
            </div>
            <div className="bento-item glass-card">
              <i className="bi bi-funnel-fill fs-1 mb-3"></i>
              <h5 className="fw-bold">Визуальная воронка</h5>
              <p>Настраивайте сценарии ответов и ведите клиента по воронке.</p>
            </div>
            <div className="bento-item glass-card">
              <i className="bi bi-people-fill fs-1 mb-3"></i>
              <h5 className="fw-bold">Командная работа</h5>
              <p>Добавляйте коллег и управляйте аккаунтами вместе.</p>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works Section */}
      <section id="how-it-works" className="py-5">
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="fw-bold text-white">Запуск за 3 минуты</h2>
          </div>
          <div className="row text-center align-items-center">
            <div className="col-lg-3 mb-4 step-container">
              <div className="glass-card p-4 h-100">
                <div className="step-number">1</div>
                <h5 className="fw-bold mt-4">Подключите аккаунт</h5>
                <p>Безопасная авторизация в один клик.</p>
              </div>
            </div>
            <div className="col-lg-1 step-arrow d-none d-lg-block">→</div>
            <div className="col-lg-4 mb-4 step-container">
              <div className="glass-card p-4 h-100">
                <div className="step-number">2</div>
                <h5 className="fw-bold mt-4">Опишите целевой портрет</h5>
                <p>Укажите, кому отправлять сообщения (должность, сфера, город).</p>
              </div>
            </div>
            <div className="col-lg-1 step-arrow d-none d-lg-block">→</div>
            <div className="col-lg-3 mb-4 step-container">
              <div className="glass-card p-4 h-100">
                <div className="step-number">3</div>
                <h5 className="fw-bold mt-4">Наблюдайте за ростом</h5>
                <p>Получайте уведомления о новых ответах.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-5">
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="fw-bold text-white">Прозрачные тарифы</h2>
          </div>
          <div className="row justify-content-center">
            <div className="col-lg-4 mb-4">
              <div className="glass-card pricing-card p-4 text-center h-100">
                <h5 className="fw-bold text-uppercase">Pro</h5>
                <h1 className="display-4 fw-bold my-3">2990₽<span className="fs-5 op-50">/мес</span></h1>
                <ul className="list-unstyled my-4 text-start">
                  <li><i class="bi bi-check-circle-fill me-2"></i>1 аккаунт TenChat</li>
                  <li><i class="bi bi-check-circle-fill me-2"></i>AI-персонализация</li>
                  <li><i class="bi bi-check-circle-fill me-2"></i>Live-аналитика</li>
                </ul>
                <button className="btn btn-outline-light rounded-pill mt-auto">Выбрать тариф</button>
              </div>
            </div>
            <div className="col-lg-4 mb-4">
              <div className="glass-card pricing-card popular-card p-4 text-center h-100">
                <span className="badge rounded-pill position-absolute top-0 start-50 translate-middle">Хит продаж</span>
                <h5 className="fw-bold text-uppercase">Business</h5>
                <h1 className="display-4 fw-bold my-3">7990₽<span className="fs-5 op-50">/мес</span></h1>
                <ul className="list-unstyled my-4 text-start">
                  <li><i class="bi bi-check-circle-fill me-2"></i>5 аккаунтов TenChat</li>
                  <li><i class="bi bi-check-circle-fill me-2"></i>Все функции Pro</li>
                  <li><i class="bi bi-check-circle-fill me-2"></i>Визуальная воронка</li>
                  <li><i class="bi bi-check-circle-fill me-2"></i>Командный доступ</li>
                </ul>
                <button className="btn btn-light rounded-pill mt-auto fw-bold">Попробовать бесплатно</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-5">
        <div className="container" style={{ maxWidth: '800px' }}>
          <div className="text-center mb-5">
            <h2 className="fw-bold text-white">Остались вопросы?</h2>
          </div>
          <div className="accordion accordion-flush" id="faqAccordion">
            <div class="accordion-item glass-card mb-3"><h2 class="accordion-header"><button class="accordion-button collapsed bg-transparent text-white fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">Насколько это безопасно для моего аккаунта?</button></h2><div id="collapseOne" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body text-white-50">Максимально. Мы не используем API TenChat, а эмулируем действия реального пользователя с уникальным "цифровым отпечатком" и умными задержками. Для соцсети это выглядит так, будто вы сами зашли в аккаунт и пишете сообщения.</div></div></div>
            <div class="accordion-item glass-card mb-3"><h2 class="accordion-header"><button class="accordion-button collapsed bg-transparent text-white fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo">Что такое AI-персонализация?</button></h2><div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body text-white-50">Наша нейросеть (на базе GPT-4) изучает профиль человека (описание, посты, опыт работы) и генерирует уникальное первое сообщение, которое учитывает этот контекст. Конверсия в ответ у таких сообщений в 3-4 раза выше, чем у шаблонных.</div></div></div>
            <div class="accordion-item glass-card mb-3"><h2 class="accordion-header"><button class="accordion-button collapsed bg-transparent text-white fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree">Могу ли я отменить подписку в любой момент?</button></h2><div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#faqAccordion"><div class="accordion-body text-white-50">Да, конечно. Вы можете отменить подписку в один клик в личном кабинете в любое время. Доступ к сервису сохранится до конца оплаченного периода.</div></div></div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-white-50 py-4">
        <div className="container text-center">
          <p className="mb-0">&copy; 2025 TenSender. Все права защищены.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
